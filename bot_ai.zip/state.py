from collections import deque
from typing import Dict, Any
from data_loader import build_system_intro

SYSTEM_INTRO_FULL = build_system_intro()

user_states: Dict[int, Dict[str, Any]] = {}
HISTORY_MAXLEN = 10

def init_state(chat_id: int, keep_background: bool = True):
    prev_bg = user_states.get(chat_id, {}).get("user_background", "") if keep_background else ""
    user_states[chat_id] = {
        "mode": "",
        "sub_mode": "",
        "user_background": prev_bg,
        "diploma": None,
        "history": deque(maxlen=HISTORY_MAXLEN),
        "last_message": ""
    }
    user_states[chat_id]["history"].clear()
    user_states[chat_id]["history"].append(("system", SYSTEM_INTRO_FULL))
    return user_states[chat_id]

def ensure_state(chat_id: int):
    if chat_id not in user_states:
        init_state(chat_id, keep_background=False)
    return user_states[chat_id]