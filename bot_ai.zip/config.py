import os
import logging
from dotenv import load_dotenv

# Try import pymorphy2 (optional)
try:
    import pymorphy2
    morph = pymorphy2.MorphAnalyzer()
    MORPH_AVAILABLE = True
except Exception:
    morph = None
    MORPH_AVAILABLE = False

# Try import Mistral
try:
    from mistralai import Mistral
    MISTRAL_AVAILABLE = True
except Exception:
    MISTRAL_AVAILABLE = False

# Logging setup
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY")
MISTRAL_MODEL = os.getenv("MISTRAL_MODEL", "mistral-medium")

if not TELEGRAM_TOKEN:
    raise RuntimeError("Please set TELEGRAM_TOKEN in .env")

if not MISTRAL_API_KEY:
    logger.warning("MISTRAL_API_KEY not found — LLM calls will be stubbed/unavailable.")

mistral_client = None
if MISTRAL_AVAILABLE and MISTRAL_API_KEY:
    try:
        mistral_client = Mistral(api_key=MISTRAL_API_KEY)
    except Exception as e:
        logger.exception("Failed to init Mistral client: %s", e)
        mistral_client = None
else:
    logger.info("Mistral client not available; LLM calls will be stubbed or skipped.")
