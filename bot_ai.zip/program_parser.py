import os
import json
import requests
from bs4 import BeautifulSoup

URLS = {
    "ai": "https://abit.itmo.ru/program/master/ai",
    "ai_product": "https://abit.itmo.ru/program/master/ai_product",
}

HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; Bot/1.0)"}


def get_next_data_json(url):
    """Загружает страницу и достает JSON из __NEXT_DATA__"""
    resp = requests.get(url, headers=HEADERS, timeout=15)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")
    script_tag = soup.find("script", id="__NEXT_DATA__", type="application/json")
    if not script_tag:
        raise ValueError(f"Не найден __NEXT_DATA__ на {url}")
    return json.loads(script_tag.get_text())


def parse_program_data(url):
    """Парсит описание программы с сайта"""
    data = get_next_data_json(url)
    page_props = data.get("props", {}).get("pageProps", {})
    api_program = page_props.get("apiProgram", {})
    json_program = page_props.get("jsonProgram", {})

    program_info = {}

    # Основная информация
    program_info["title"] = api_program.get("title", "")
    program_info["faculties"] = api_program.get("faculties", [])
    program_info["form"] = api_program.get("educationForm", "")
    program_info["duration"] = api_program.get("duration", "")
    program_info["language"] = api_program.get("language", "")
    program_info["cost"] = api_program.get("educationCost", "")
    program_info["has_dormitory"] = api_program.get("hasDormitory", "")

    # Описание и карьера
    program_info["about"] = json_program.get("about", {}).get("desc", "")
    program_info["career"] = json_program.get("career", {}).get("lead", "")
    program_info["achievements"] = json_program.get("achievements", [])

    # FAQ
    faq_list = []
    for item in json_program.get("faq", []):
        q = item.get("question", "")
        a = item.get("answer", "")
        if q and a:
            faq_list.append({"question": q, "answer": a})
    program_info["faq"] = faq_list

    # PDF план (если есть в apiProgram -> directions -> files)
    pdf_link = ""
    for direction in api_program.get("directions", []):
        for file_info in direction.get("files", []):
            if file_info.get("url", "").endswith(".pdf"):
                pdf_link = file_info["url"]
                break
    program_info["plan_pdf_url"] = pdf_link

    return program_info


def save_program_data():
    os.makedirs("data/program", exist_ok=True)
    for name, url in URLS.items():
        try:
            print(f"Парсим {name} -> {url}")
            data = parse_program_data(url)
            with open(f"data/program/{name}.json", "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            print(f"Сохранено: data/program/{name}.json")
        except Exception as e:
            print(f"Ошибка при парсинге {name}: {e}")


if __name__ == "__main__":
    save_program_data()
