import asyncio
import re
from telegram import Update
from telegram.ext import ContextTypes
from state import ensure_state, init_state, user_states
from keyboards import main_menu_kb, after_answer_kb, diploma_kb, recs_background_kb, recs_program_choice_kb
from data_loader import load_json_if_exists, find_program_file, find_plan_file, extract_text_from_chunks
from llm import quick_keyword_check, relevance_classifier_via_llm, build_messages_from_history, ask_mistral, validate_background
from config import logger

# ---------------- Start ----------------
async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    init_state(chat_id, keep_background=False)
    await update.message.reply_text(
        "Привет! Я помогу выбрать магистерскую программу и рекомендовать курсы.\nВыберите режим:",
        reply_markup=main_menu_kb()
    )

# ---------------- Callback ----------------
async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    try:
        await query.answer()
    except Exception as e:
        logger.debug("callback.answer() failed: %s", e)
    chat_id = query.message.chat.id
    state = ensure_state(chat_id)
    data = query.data
    logger.info("Callback %s from %s", data, chat_id)

    # --- Меню ---
    if data == "mode_questions":
        state["mode"] = "questions"
        state["sub_mode"] = "await_question"
        await query.edit_message_text(
            "Режим вопросов: задавайте вопросы по программам.",
            reply_markup=after_answer_kb()
        )
        return

    if data == "mode_recommendations":
        state["mode"] = "recommendations"
        if state.get("diploma") != "yes":
            state["diploma"] = None
            state["sub_mode"] = "ask_diploma"
            await query.edit_message_text(
                "Сначала: есть ли у вас диплом бакалавра?",
                reply_markup=diploma_kb()
            )
            return
        if not state.get("user_background"):
            state["sub_mode"] = "await_background"
            await query.edit_message_text(
                "Расскажите о своём бэкграунде.",
                reply_markup=after_answer_kb()
            )
        else:
            state["sub_mode"] = "confirm_background"
            await query.edit_message_text(
                f"Сохранён бэкграунд:\n{state['user_background']}\nИзменить или продолжить?",
                reply_markup=recs_background_kb(has_bg=True)
            )
        return

    # --- Работа с бэкграундом ---
    if data == "edit_background":
        state["sub_mode"] = "await_background"
        await query.edit_message_text("Введите новый бэкграунд.", reply_markup=after_answer_kb())
        return

    if data == "clear_background":
        state["user_background"] = ""
        state["sub_mode"] = "await_background"
        await query.edit_message_text("Бэкграунд удалён. Введите новый.", reply_markup=after_answer_kb())
        return

    if data == "recs_choose_program":
        state["sub_mode"] = "choose_program_for_recs"
        await query.edit_message_text("Выберите программу:", reply_markup=recs_program_choice_kb())
        return

    if data in ("r_prog_1", "r_prog_2", "r_both"):
        if data == "r_prog_1":
            state["selected_programs"] = ["ai"]
        elif data == "r_prog_2":
            state["selected_programs"] = ["ai_product"]
        else:
            state["selected_programs"] = ["ai", "ai_product"]

        if state.get("diploma") != "yes":
            await query.edit_message_text(
                "Без диплома поступление невозможно.",
                reply_markup=main_menu_kb()
            )
            prev_bg = state.get("user_background", "")
            init_state(chat_id)
            user_states[chat_id]["user_background"] = prev_bg
            return

        # --- Генерация рекомендаций ---
        state["sub_mode"] = "await_question_recs"
        bg_text = state.get("user_background", "(не указан)")
        program_map = {"ai": "Program AI", "ai_product": "Program AI Product"}
        program_contexts = []
        for prog in state["selected_programs"]:
            prog_text = load_json_if_exists(find_program_file(prog, "data/program"))
            plan_text = load_json_if_exists(find_plan_file(prog, "data/parsed_pdf"))
            prog_desc = extract_text_from_chunks(prog_text) if prog_text else ""
            plan_desc = extract_text_from_chunks(plan_text) if plan_text else ""
            program_contexts.append(f"Описание {program_map.get(prog, prog)}:\n{prog_desc}\n\nПлан:\n{plan_desc}")

        llm_prompt = (
            f"Бэкграунд:\n{bg_text}\n\n"
            f"{''.join(program_contexts)}\n\n"
            "Порекомендуй 3–5 выборных дисциплин."
        )

        state["history"].append(("user", llm_prompt))
        messages = build_messages_from_history(state["history"], None)

        async def run_and_send():
            answer = await ask_mistral(messages)
            state["history"].append(("assistant", answer))
            await context.bot.send_message(chat_id, f"Рекомендация:\n{answer}", reply_markup=after_answer_kb())

        asyncio.create_task(run_and_send())
        await query.edit_message_text(
            "Генерирую рекомендации...",
            reply_markup=after_answer_kb()
        )
        return

    # --- Диплом ---
    if data == "diploma_yes":
        state["diploma"] = "yes"
        state["sub_mode"] = "await_background"
        await query.edit_message_text("Опишите ваш бэкграунд.", reply_markup=after_answer_kb())
        return

    if data == "diploma_no":
        state["diploma"] = "no"
        prev_bg = state.get("user_background", "")
        init_state(chat_id)
        user_states[chat_id]["user_background"] = prev_bg
        await query.edit_message_text(
            "Без диплома поступление невозможно.",
            reply_markup=main_menu_kb()
        )
        return

    if data == "back_to_main":
        prev_bg = state.get("user_background", "")
        init_state(chat_id)
        user_states[chat_id]["user_background"] = prev_bg
        await query.edit_message_text("Главное меню:", reply_markup=main_menu_kb())
        return

    await query.edit_message_text("Неизвестная команда.", reply_markup=main_menu_kb())

# ---------------- Messages ----------------
async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    text = (update.message.text or "").strip()
    state = ensure_state(chat_id)
    state["last_message"] = text

    if not state["mode"]:
        await update.message.reply_text("Выберите режим:", reply_markup=main_menu_kb())
        return

    # --- Вопросы ---
    if state["mode"] == "questions":
        if not text:
            await update.message.reply_text("Введите вопрос.")
            return
        general_prog_patterns = re.compile(r"(програм+|магистратур+)", re.I)
        if quick_keyword_check(text) or general_prog_patterns.search(text):
            is_rel = True
        else:
            is_rel = await relevance_classifier_via_llm(text)
        if not is_rel:
            await update.message.reply_text("Вопрос не по теме.", reply_markup=after_answer_kb())
            return
        state["history"].append(("user", text))
        messages = build_messages_from_history(state["history"], text)
        await update.message.reply_text("Готовлю ответ...", reply_markup=after_answer_kb())
        answer = await ask_mistral(messages)
        state["history"].append(("assistant", answer))
        await update.message.reply_text(answer, reply_markup=after_answer_kb())
        return

    # --- Рекомендации ---
    if state["mode"] == "recommendations":
        sub = state.get("sub_mode", "")
        if sub == "ask_diploma":
            await update.message.reply_text("Укажите диплом через кнопки.", reply_markup=diploma_kb())
            return
        if sub == "await_background":
            if not text:
                await update.message.reply_text("Опишите бэкграунд.")
                return
            valid = await validate_background(text)
            if not valid:
                await update.message.reply_text("Бэкграунд некорректен.", reply_markup=after_answer_kb())
                return
            state["user_background"] = text
            state["sub_mode"] = "confirm_background"
            await update.message.reply_text(
                f"Бэкграунд сохранён:\n{state['user_background']}",
                reply_markup=recs_background_kb(has_bg=True)
            )
            return
        if sub == "choose_program_for_recs" and text:
            await update.message.reply_text(
                "Используйте кнопки для выбора программы.",
                reply_markup=recs_program_choice_kb()
            )
            return
