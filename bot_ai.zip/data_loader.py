import os
import re
import glob
import json
from html import unescape
from config import logger
from typing import Any

# ---------------- Загрузка JSON ----------------
def load_json_if_exists(path: str):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.warning("Failed to load JSON %s: %s", path, e)
        return None

def find_program_file(basename_token: str, folder: str = "data/program"):
    files = glob.glob(os.path.join(folder, f"*{basename_token}*.json"))
    return files[0] if files else None

def find_plan_file(basename_token: str, folder: str = "data/parsed_pdf"):
    files = glob.glob(os.path.join(folder, f"*{basename_token}*.json"))
    return files[0] if files else None

# ---------------- Очистка HTML ----------------
def clean_html(text: str) -> str:
    if not text:
        return ""
    text = unescape(text)
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<.*?>", "", text)
    return text.strip()

# ---------------- Извлечение текста из JSON ----------------
def extract_text_from_chunks(chunks: Any):
    if not chunks:
        return ""

    if isinstance(chunks, dict):
        chunks = [chunks]

    texts = []
    for ch in chunks:
        if not isinstance(ch, dict):
            continue

        if "title" in ch:
            texts.append(ch["title"])
        if "about" in ch:
            texts.append(clean_html(ch["about"]))
        if "career" in ch:
            texts.append(clean_html(ch["career"]))

        if "faq" in ch and isinstance(ch["faq"], list):
            for item in ch["faq"]:
                if isinstance(item, dict):
                    q = clean_html(item.get("question", ""))
                    a = clean_html(item.get("answer", ""))
                    if q and a:
                        texts.append(f"Q: {q}\nA: {a}")

        if "achievements" in ch and isinstance(ch["achievements"], list):
            for ach in ch["achievements"]:
                if isinstance(ach, dict):
                    txt = clean_html(ach.get("text", ""))
                    if txt:
                        texts.append(f"Achievement: {txt}")

    texts = [t for t in texts if t.strip()]
    texts = list(dict.fromkeys(texts))

    joined = "\n\n".join(texts)
    if len(joined) > 4000:
        joined = joined[:3900] + "\n\n...(контент сокращён)..."
    return joined

# ---------------- Сборка системного интро ----------------
def build_system_intro():
    def load_with_log(find_func, token, folder):
        path = find_func(token, folder)
        if not path:
            logger.warning(f"Файл не найден: {token} в {folder}")
            return ""
        data = load_json_if_exists(path)
        if not data:
            logger.warning(f"Файл пустой или не удалось загрузить: {path}")
            return ""
        text = extract_text_from_chunks(data)
        logger.info(f"Загружен {path}, длина текста: {len(text)}")
        return text

    ai_text = load_with_log(find_program_file, "ai", "data/program")
    ai_plan_text = load_with_log(find_plan_file, "ai", "data/parsed_pdf")
    prod_text = load_with_log(find_program_file, "ai_product", "data/program") \
        or load_with_log(find_program_file, "ai-product", "data/program")
    prod_plan_text = load_with_log(find_plan_file, "ai_product", "data/parsed_pdf") \
        or load_with_log(find_plan_file, "ai-product", "data/parsed_pdf")

    intro = (
        "Описание и учебные планы двух магистерских программ (фиксированный контекст):\n\n"
        "--- Program AI ---\n"
        f"{ai_text}\n\nПлан:\n{ai_plan_text}\n\n"
        "--- Program AI Product ---\n"
        f"{prod_text}\n\nПлан:\n{prod_plan_text}\n"
    )

    max_len = 7000
    if len(intro) > max_len:
        intro = intro[:max_len] + "\n\n...(контент сокращён)..."
    return intro