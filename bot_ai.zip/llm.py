import asyncio
from config import logger, MORPH_AVAILABLE, morph, mistral_client, MISTRAL_AVAILABLE, MISTRAL_MODEL
from state import SYSTEM_INTRO_FULL
from typing import List
from collections import deque

# ---------------- Keywords ----------------
PROGRAM_KEYWORDS = [
    "магистратура", "программа", "курс", "обучение", "стоимость",
    "поступить", "общежитие", "стипендия", "преподаватель",
    "план", "длительность", "формат", "стажировка", "практика",
    "проекты", "карьера", "опыт", "бакалавр", "специалитет", "универ", "вуз", "навык"
]

PROGRAM_SYNONYMS = {
    "обучение": ["учёба", "учеба", "образование", "занятия"],
    "поступить": ["поступление", "зачисление"],
    "стоимость": ["цена", "оплата", "платно", "платное"],
    "общежитие": ["дорм", "жильё", "жилье", "проживание"],
    "стипендия": ["грант", "пособие"],
}

def normalize_token(token: str) -> str:
    if MORPH_AVAILABLE and token:
        try:
            return morph.parse(token)[0].normal_form
        except Exception:
            return token.lower()
    return (token or "").lower()

KEYWORD_SET = set()
for k in PROGRAM_KEYWORDS:
    KEYWORD_SET.add(normalize_token(k))
for base, syns in PROGRAM_SYNONYMS.items():
    KEYWORD_SET.add(normalize_token(base))
    for s in syns:
        KEYWORD_SET.add(normalize_token(s))

# ---------------- Токенизация ----------------
def tokenize_norm(text: str) -> List[str]:
    text = (text or "").lower()
    tokens = [w.strip(".,!?;:()[]\"'") for w in text.split()]
    if MORPH_AVAILABLE:
        res = []
        for t in tokens:
            if not t:
                continue
            try:
                res.append(morph.parse(t)[0].normal_form)
            except Exception:
                res.append(t)
        return res
    return [t for t in tokens if t]

def quick_keyword_check(text: str) -> bool:
    return any(t in KEYWORD_SET for t in tokenize_norm(text))

# ---------------- LLM Wrappers ----------------
def ask_mistral_sync(messages: List[dict]) -> str:
    if not MISTRAL_AVAILABLE or not mistral_client:
        return "LLM недоступна."
    try:
        resp = mistral_client.chat.complete(model=MISTRAL_MODEL, messages=messages)
        try:
            return resp.choices[0].message.content
        except Exception:
            return str(resp)
    except Exception as e:
        logger.exception("Mistral error: %s", e)
        return f"Ошибка LLM: {e}"

async def ask_mistral(messages: List[dict]) -> str:
    return await asyncio.to_thread(ask_mistral_sync, messages)

async def relevance_classifier_via_llm(question: str) -> bool:
    if not MISTRAL_AVAILABLE or not mistral_client:
        return False
    system = "Ответь 'да' или 'нет': относится ли вопрос к магистерским программам?"
    minimal_ctx = SYSTEM_INTRO_FULL[:1800] + "\n\n"
    user_text = f"{minimal_ctx}Вопрос: {question}\nОтвет (да/нет):"
    try:
        resp_text = await ask_mistral([{"role":"system","content":system},{"role":"user","content":user_text}])
        out = (resp_text or "").lower()
        return "да" in out or "yes" in out
    except Exception:
        logger.exception("LLM relevance check failed")
        return False

# ---------------- Background Validation ----------------
async def validate_background(text: str) -> bool:
    if not text or not text.strip():
        return False
    txt = text.strip()
    words = txt.split()
    if len(words) < 5 or len(txt) < 15:
        pass_flag = False
    else:
        letters = sum(1 for ch in txt if ch.isalpha())
        ratio = letters / max(1, len(txt))
        pass_flag = ratio >= 0.5
    if pass_flag:
        lower = txt.lower()
        pos_tokens = ["бакалавр", "бак", "универ", "вуз", "опыт", "работ", "стаж", "ing", "python", "ml", "data", "аналит", "инженер", "специал"]
        if any(p in lower for p in pos_tokens):
            return True
        return True
    if MISTRAL_AVAILABLE and mistral_client:
        system = "Ответь 'да', если текст содержит образование/опыт/навыки."
        try:
            resp = await ask_mistral([{"role":"system","content":system},{"role":"user","content":txt}])
            out = (resp or "").lower()
            return "да" in out or "yes" in out
        except Exception:
            logger.exception("Background LLM check failed")
            return False
    return False

# ---------------- Messages Builder ----------------
def build_messages_from_history(history: deque, current_query: str = None) -> List[dict]:
    system_prompt = (
        "Ты — экспертный помощник по двум магистерским программам. "
        "Отвечай кратко (1–3 предложения или до 3 буллетов). "
        "Чётко опирайся на предоставленные описания и учебные планы. "
        "Если вопрос нерелевантен — вежливо откажись."
    )
    system_intro = ""
    if history:
        first_role, first_text = history[0]
        if first_role == "system":
            system_intro = first_text
    msgs = [{"role": "system", "content": system_prompt + "\n\n" + system_intro}]
    for role, txt in list(history)[1:]:
        msgs.append({"role": role if role in ("user", "assistant") else "user", "content": txt})
    if current_query:
        msgs.append({"role": "user", "content": current_query})
    return msgs