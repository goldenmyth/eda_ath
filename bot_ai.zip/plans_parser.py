import pdfplumber
import json
import pathlib

# Входные PDF
PDF_FILES = {
    "ai": "pdf_plans/10033-abit.pdf",
    "ai_product": "pdf_plans/10130-abit.pdf"
}

# Папка для сохранения
OUTPUT_DIR = pathlib.Path("data/parsed_pdf")
OUTPUT_DIR.mkdir(exist_ok=True)

def parse_pdf(file_path):
    data = []
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            table = page.extract_table()
            if not table:
                continue

            # Пропускаем заголовок
            for row in table[1:]:
                if len(row) < 4:
                    continue

                semester = str(row[0]).strip() if row[0] else ""
                discipline = str(row[1]).strip() if row[1] else ""
                credits = str(row[2]).strip() if row[2] else ""
                hours = str(row[3]).strip() if row[3] else ""

                # 1) Пропускаем, если семестр содержит более одного числа
                if semester and len(semester.split()) > 1:
                    continue

                # 2) Пропускаем, если во втором столбце "модуль" или "практика"
                low_disc = discipline.lower()
                if "модуль" in low_disc or "практика" in low_disc:
                    continue

                data.append({
                    "semester": semester,
                    "discipline": discipline,
                    "credits": credits,
                    "hours": hours
                })
    return data

def save_json(data, filename):
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    for prog_name, pdf_file in PDF_FILES.items():
        parsed_data = parse_pdf(pdf_file)
        output_file = OUTPUT_DIR / f"{prog_name}_plan.json"
        save_json(parsed_data, output_file)
        print(f"[OK] {pdf_file} → {output_file}")
