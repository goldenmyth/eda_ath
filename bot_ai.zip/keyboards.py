from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def main_menu_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📚 Вопросы по программам", callback_data="mode_questions")],
        [InlineKeyboardButton("🎯 Рекомендации по курсам", callback_data="mode_recommendations")]
    ])

def recs_background_kb(has_bg: bool):
    buttons = []
    if has_bg:
        buttons.append([
            InlineKeyboardButton("📝 Изменить бэкграунд", callback_data="edit_background"),
            InlineKeyboardButton("🗑 Очистить бэкграунд", callback_data="clear_background")
        ])
    buttons.append([InlineKeyboardButton("Продолжить", callback_data="recs_choose_program")])
    buttons.append([InlineKeyboardButton("⬅ Назад", callback_data="back_to_main")])
    return InlineKeyboardMarkup(buttons)

def recs_program_choice_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Программа AI", callback_data="r_prog_1"),
         InlineKeyboardButton("Программа AI Product", callback_data="r_prog_2")],
        [InlineKeyboardButton("Обе программы", callback_data="r_both")],
        [InlineKeyboardButton("⬅ Назад", callback_data="back_to_main")]
    ])

def diploma_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Да, есть диплом", callback_data="diploma_yes"),
         InlineKeyboardButton("Нет, нет диплома", callback_data="diploma_no")]
    ])

def after_answer_kb():
    return InlineKeyboardMarkup([[InlineKeyboardButton("⬅ Назад", callback_data="back_to_main")]])